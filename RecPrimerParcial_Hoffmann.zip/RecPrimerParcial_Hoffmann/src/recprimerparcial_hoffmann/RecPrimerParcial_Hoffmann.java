package recprimerparcial_hoffmann;

public class RecPrimerParcial_Hoffmann {

    public static void main(String[] args) {
        JardinBotanico jardin = new JardinBotanico("Jardin Botanico Nacional");
        cargarJardin(jardin);
        
        System.out.println("Plantas registradas en el jardin:");
        jardin.mostrarPlantas();
        System.out.println();
        
        System.out.println("Podando plantas:");
        jardin.podarPlantas();
    }
    
    public static void cargarJardin(JardinBotanico jardin) {
        Arbol a1 = new Arbol("Roble", "Zona Norte", "Templado", 20);
        Arbusto b1 = new Arbusto("Lavanda", "Zona Este", "Mediterraneo", 5);
        Flor f1 = new Flor("Rosa", "Zona Sur", "Templado", Temporada.PRIMAVERA);
        Arbusto b2 = new Arbusto("Hortensia", "Zona Oeste", "Templado", 7);
        Arbol a2 = new Arbol("Pino", "Zona Central", "Frio", 30);
        
        jardin.agregarPlanta(a1);
        jardin.agregarPlanta(b1);
        jardin.agregarPlanta(f1);
        jardin.agregarPlanta(b2);
        jardin.agregarPlanta(a2);
        
        // Intento de agregar planta duplicada
        try {
            jardin.agregarPlanta(a1);
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
        
        // Intento de agregar planta nula
        try {
            jardin.agregarPlanta(null);
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}



package recprimerparcial_hoffmann;

public enum Temporada {
    PRIMAVERA,
    VERANO,
    OTONO,
    INVIERNO
}




package recprimerparcial_hoffmann;

public class PlantaDuplicadaException extends RuntimeException {
    private static final String MESSAGE = "Planta duplicada: ya fue agregada anteriormente en esa ubicacion.";

    public PlantaDuplicadaException() {
        super(MESSAGE);
    }
}


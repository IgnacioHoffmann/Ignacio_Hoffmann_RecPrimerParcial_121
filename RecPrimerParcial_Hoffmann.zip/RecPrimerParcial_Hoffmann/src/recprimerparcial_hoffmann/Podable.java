
package recprimerparcial_hoffmann;

public interface Podable {
    void podar();
}

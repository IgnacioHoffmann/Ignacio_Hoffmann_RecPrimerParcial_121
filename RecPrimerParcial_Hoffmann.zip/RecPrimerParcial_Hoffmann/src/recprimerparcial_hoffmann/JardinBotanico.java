package recprimerparcial_hoffmann;

import java.util.ArrayList;
import java.util.List;

public class JardinBotanico {
    private String nombre;
    private List<Planta> plantas;

    public JardinBotanico(String nombre) {
        this.nombre = nombre;
        this.plantas = new ArrayList<>();
    }

    private boolean buscarPlanta(Planta planta) {
        return plantas.contains(planta);
    }

    public void agregarPlanta(Planta planta) {
        if (planta == null) {
            throw new NullPointerException("La planta no puede ser nula.");
        }
        if (buscarPlanta(planta)) {
            throw new PlantaDuplicadaException();
        }
        plantas.add(planta);
    }

    public void mostrarPlantas() {
        if (!plantas.isEmpty()) {
            for (Planta planta : plantas) {
                System.out.println(planta);
                System.out.println("--------------------");
            }
        }
    }

    public void podarPlantas() {
        if (!plantas.isEmpty()) {
            for (Planta planta : plantas) {
                if (planta instanceof Podable podable) {
                    podable.podar();
                } else {
                    System.out.println("La planta '" + planta.getNombre() + "' es una flor y no requiere poda.");
                }
            }
        }
    }
}

